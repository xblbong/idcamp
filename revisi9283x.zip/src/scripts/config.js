const CONFIG = {
  BASE_URL: "https://story-api.dicoding.dev/v1",
  ACCESS_TOKEN_KEY: "accessToken",
};

export default CONFIG;
